import time, pip, os

#check for package
def install(package):
    pip.main(['install', package])

#install and import selenium
install("selenium")
install("xlwt")

from selenium import webdriver
import xlwt

#initialize lists and working directory for chromedriver
dl_speed = list()
ul_speed = list()
working_dir = os.getcwd()
working_dir += "\chromedriver.exe"

#Take user input for iteration count
iteration = input("How many times to iterate speedtest page?")
iteration = int(iteration)

#Open Chrome, go to speedtest.net
browser = webdriver.Chrome(working_dir)
browser.get("http://beta.speedtest.net")
time.sleep(5)

#Change servers to Raleigh
change_server = browser.find_element_by_class_name("btn-server-select")
change_server.click()
time.sleep(3)
search_bar = browser.find_element_by_id("host-search")
search_bar.send_keys("Raleigh, NC")
time.sleep(2)

#Select Raleigh Server
select_server = browser.find_element_by_class_name("host-location")
select_server.click()

#Complete 'iteration' number of iterations
while iteration > 0:
    iteration -= 1
    link = browser.find_element_by_class_name("start-text")
    link.click()
    time.sleep(60)
    for elem in browser.find_elements_by_xpath('.//span[@class = "result-data-large number result-data-value download-speed"]'):
        dl_speed.append(elem.text)
    for elem in browser.find_elements_by_xpath('.//span[@class = "result-data-large number result-data-value upload-speed"]'):
        ul_speed.append(elem.text)

#Open a spreadsheet
workbook = xlwt.Workbook()
sheet = workbook.add_sheet("Speedtest", cell_overwrite_ok=True)

#Put Titles
sheet.write(0,0,"Download")
sheet.write(0,1,"Upload")

#Insert dl and ul speeds
x = 1
for speed in dl_speed:
    sheet.write(x,0,speed)
    x += 1
x = 1
for speed in ul_speed:
    sheet.write(x,1,speed)
    x += 1

workbook.save("Speedest_results.xls")

#self explainatory
print "End of script."

